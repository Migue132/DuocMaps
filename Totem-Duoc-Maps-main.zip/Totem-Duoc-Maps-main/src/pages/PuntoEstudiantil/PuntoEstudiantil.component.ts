import { Component } from "@angular/core";
@Component({
    selector: 'PuntoEstudiantil',
    templateUrl: './PuntoEstudiantil.component.html',
    styleUrls: ['./PuntoEstudiantil.component.css']
})
export class PuntoEstudiantilComponent{

}