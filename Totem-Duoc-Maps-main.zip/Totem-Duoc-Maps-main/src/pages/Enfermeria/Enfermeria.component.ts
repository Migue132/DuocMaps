import { Component } from "@angular/core";
@Component({
    selector: 'Enfermeria',
    templateUrl: './Enfermeria.component.html',
    styleUrls: ['./Enfermeria.component.css']
})
export class EnfermeriaComponent{
    
}