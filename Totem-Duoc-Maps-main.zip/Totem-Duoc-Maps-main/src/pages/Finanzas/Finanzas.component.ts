import { Component } from "@angular/core";
@Component({
   selector: 'Finanzas',
   templateUrl: './Finanzas.component.html',
   styleUrls: ['./Finanzas.component.css']  
})
export class FinanzasComponent{
    
}