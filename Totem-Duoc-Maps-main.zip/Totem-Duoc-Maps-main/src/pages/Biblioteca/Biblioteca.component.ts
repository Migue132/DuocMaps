import { Component } from "@angular/core";
@Component({
    selector: 'Biblioteca',
    templateUrl: './Biblioteca.component.html',
    styleUrls: ['./Biblioteca.component.css']
})
export class BibliotecaComponent{
    
}