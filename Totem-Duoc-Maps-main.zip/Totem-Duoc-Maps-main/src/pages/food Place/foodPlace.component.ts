import { Component } from "@angular/core";
@Component({
    selector: 'food-place',
    templateUrl: './foodPlace.component.html',
    styleUrls: ['./foodPlace.component.css']
})
export class FoodPlaceComponent{

}