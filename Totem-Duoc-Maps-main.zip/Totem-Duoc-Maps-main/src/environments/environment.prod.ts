export const environment = {
  production: true,
  firebaseConfig :{
    apiKey: "AIzaSyAH4komYvtvuAI5eUZuxjrL-ntpRd6P9xU",
    authDomain: "duocmaps-e980c.firebaseapp.com",
    projectId: "duocmaps-e980c",
    storageBucket: "duocmaps-e980c.appspot.com",
    messagingSenderId: "207293455180",
    appId: "1:207293455180:web:21a14bdd5fb696dfe1cde9",
    measurementId: "G-E85EEXGDFN"
  }
};
